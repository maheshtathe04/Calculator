#!/usr/bin/env python
# coding: utf-8

# # 1st Calculator
# ### calculate with all operator

# In[4]:


def c():                
    while True:          
        a=int(input("a="))
        b=int(input("b="))
        print(f"sum of a+b={a+b}")
        print(f"minus of a-b={a-b}")
        print(f"multiple of a*b={a*b}")
        print(f"devide of a/b={a/b}")
        print(f"percent of a%b={a%b}")
        
        ch=input("y for quit")
        if ch=="y":
            print("thanks")
            break


# In[12]:


c()


#  # 2nd  Calculator
#  ### calculate with one operator

# In[13]:


def z():              
    while True:            
        a=int(input())
        b=int(input())
        operator=input("enter operator (-,+,*,%,/): ")
        if (operator == "-"):
            print(a-b)
        elif (operator == "+"):
            print(a+b)
        elif (operator == "*"):
            print(a*b)
        elif (operator == "%"):
            print(a%b)
        elif (operator == "/"):
            print(a/b)  
        ch=input("y for quit")
        if ch=="y":
            print("thanks")
            break


# In[14]:


z()

